from setuptools import setup, find_packages

setup(
    name='Final_Project',
    version='0.0.1',
    packages=find_packages(),
    url='',
    license='MIT',
    author='Maggie Maido',
    author_email='maggie_maido@yahoo.com',
    description='Final Project',

)
