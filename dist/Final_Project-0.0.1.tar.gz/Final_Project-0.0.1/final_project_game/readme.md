# Hedgehog Marathon
    CPSC 4970 Final Project
    a game with the end goal of keeping our hedgehog alive

## Installation
    pip install -e .

### Usage/How to Play
    use LEFT arrow to move hedgehog left
    use RIGHT arrow to move hedgehog right
    use UP arrow to move hedgehog up
    use DOWN arrow to move hedgehog down

    keep hedgehog alive by avoiding enemies
    press spacebar when prompted to move up levels

#### Release History
    version 1.0, completed game

##### Meta
    Maggie Maido - mzm0259@auburn.edu
    https://github.com/maggiem91
