from setuptools import setup

setup(
    name='Final_Project',
    version='',
    packages=['final_project_game'],
    url='',
    license='',
    author='Maggie Maido',
    author_email='maggie_maido@yahoo.com',
    description=''
)
